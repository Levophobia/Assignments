DROP DATABASE IF EXISTS Inlämningsuppgift;

CREATE DATABASE IF NOT EXISTS Inlämningsuppgift;

Use Inlämningsuppgift;

CREATE TABLE patients(
  patients_id INT NOT NULL AUTO_INCREMENT,
  first_name VARCHAR(45),
  last_name VARCHAR(45),
  date_of_birth DATE,
  phone VARCHAR(45),
  address VARCHAR(45),
  current_status VARCHAR(45),
  clinic_id INT,
  treatment_id INT,
  PRIMARY KEY (patients_id)
  );
  
INSERT INTO patients VALUES (1, "Christoffer", "Sahlin", "1991-01-14", "158846", "Drömstigen 14", "healthy", 1, 1);
INSERT INTO patients VALUES (2, "Nicki", "Lindqvist", "2000-03-20", "452847", "Chipsgatan 12", "sick", 1, 7);
INSERT INTO patients VALUES (3, "Sanna", "Nygren", "1997-08-09", "369854", "Ljungbyvägen 10", "sick", 1, 1);
INSERT INTO patients VALUES (4, "Ida", "Melander", "2020-01-21", "158475", "Ålandsgatan 2", "unconcious", 1, 8);
INSERT INTO patients VALUES (5, "Artur", "Hollsein", "2020-11-04", "415785", "Ålandsgatan 2", "sick", 1, 3);
INSERT INTO patients VALUES (6, "Bertil", "Samuelsson", "1996-10-09", "142587", "Fantasistigen 13", "sick", 1, 3);
INSERT INTO patients VALUES (7, "Rickard", "Eriksson", "1989-02-21", "145875", "Regbågsvägen 1", "sick", 1, 2);
INSERT INTO patients VALUES (8, "Bob", "Marley", "1998-12-11", "632584", "Marleygatan 15", "deceased", 2, 5);
INSERT INTO patients VALUES (9, "Taylor", "Swift", "1978-05-20", "158475", "Swiftvägen 12", "sick", 1, 3);
INSERT INTO patients VALUES (10, "Mariah", "Carey", "1994-03-17", "256874", "Careystigen 17", "unconcious", 1, 7);
INSERT INTO patients  VALUES (11, "Led", "Zeppelin", "1987-05-16", "458963", "Zeppelinleden 18", "sick", 2, 9);
INSERT INTO patients  VALUES (12, "Ed", "Sheeran", "1978-01-02", "478521", "Sheerans väg 12", "incapacitated", 1, 4);
INSERT INTO patients  VALUES (13, "Michael", "Jackson", "1995-06-25", "458956", "Jacksons gata 47", "deceased", 2, 5);
INSERT INTO patients  VALUES (14, "Alice", "Cooper", "1985-09-09", "158865", "Coopervägen 26", "sick", 1, 6); 


UPDATE patients
SET current_status = "healthy"
WHERE patients_id = 2;

ALTER TABLE patients
ADD COLUMN age INT;

UPDATE patients SET age = 30 WHERE patients_id = 1;
UPDATE patients SET age = 29 WHERE patients_id = 2;
UPDATE patients SET age = 22 WHERE patients_id = 3;
UPDATE patients SET age = 34 WHERE patients_id = 4;
UPDATE patients SET age = 27 WHERE patients_id = 5;
UPDATE patients SET age = 19 WHERE patients_id = 6;
UPDATE patients SET age = 23 WHERE patients_id = 7;
UPDATE patients SET age = 45 WHERE patients_id = 8;
UPDATE patients SET age = 32 WHERE patients_id = 9;
UPDATE patients SET age = 26 WHERE patients_id = 10;
UPDATE patients SET age = 31 WHERE patients_id = 11;
UPDATE patients SET age = 30 WHERE patients_id = 12;
UPDATE patients SET age = 25 WHERE patients_id = 13;
UPDATE patients SET age = 21 WHERE patients_id = 14;


ALTER TABLE patients
DROP COLUMN age;

DELETE FROM patients
WHERE patients_id = 1;

DROP TABLE IF EXISTS patients;




CREATE TABLE patients(
  patient_id INT NOT NULL AUTO_INCREMENT,
  first_name VARCHAR(45),
  last_name VARCHAR(45),
  date_of_birth DATE,
  phone VARCHAR(45),
  address VARCHAR(45),
  current_status VARCHAR(45),
  clinic_id INT,
  treatment_id INT,
  PRIMARY KEY (patient_id)
  );
  
INSERT INTO patients VALUES (1, "Christoffer", "Sahlin", "1991-01-14", "158846", "Drömstigen 14", "Healthy", 1, 1);
INSERT INTO patients VALUES (2, "Nicki", "Lindqvist", "2000-03-20", "452847", "Chipsgatan 12", "Sick", 1, 7);
INSERT INTO patients VALUES (3, "Sanna", "Nygren", "1997-08-09", "369854", "Ljungbyvägen 10", "Sick", 1, 1);
INSERT INTO patients VALUES (4, "Ida", "Melander", "2000-01-21", "158475", "Ålandsgatan 2", "Unconcious", 1, 8);
INSERT INTO patients VALUES (5, "Artur", "Hollsein", "2000-11-04", "415785", "Ålandsgatan 2", "Sick", 1, 3);
INSERT INTO patients VALUES (6, "Bertil", "Samuelsson", "1996-10-09", "142587", "Fantasistigen 13", "Sick", 1, 3);
INSERT INTO patients VALUES (7, "Rickard", "Eriksson", "1989-02-21", "145875", "Regbågsvägen 1", "Sick", 1, 2);
INSERT INTO patients VALUES (8, "Bob", "Marley", "1998-12-11", "632584", "Marleygatan 15", "Deceased", 2, 5);
INSERT INTO patients VALUES (9, "Taylor", "Swift", "1978-05-20", "158475", "Swiftvägen 12", "Sick", 1, 3);
INSERT INTO patients VALUES (10, "Mariah", "Carey", "1994-03-17", "256874", "Careystigen 17", "Unconcious", 1, 7);
INSERT INTO patients  VALUES (11, "Led", "Zeppelin", "1987-05-16", "458963", "Zeppelinleden 18", "Sick", 2, 9);
INSERT INTO patients  VALUES (12, "Ed", "Sheeran", "1978-01-02", "478521", "Sheerans väg 12", "Incapacitated", 1, 4);
INSERT INTO patients  VALUES (13, "Michael", "Jackson", "1995-06-25", "458956", "Jacksons gata 47", "Deceased", 2, 5);
INSERT INTO patients  VALUES (14, "Alice", "Cooper", "1985-09-09", "158865", "Coopervägen 26", "Sick", 1, 6); 



CREATE TABLE clinics (
  clinic_id INT NOT NULL,
  name VARCHAR(45),
  address VARCHAR(45),
  phone VARCHAR(45),
  PRIMARY KEY (clinic_id)
  );
  
INSERT INTO clinics  VALUES (1, "Huerta Memorial Clinic", "Citadel Station", "256874");
INSERT INTO clinics  VALUES (2, "Pillbox Hill Medical", "Los Santos", "145876");

CREATE TABLE staff (
  staff_id INT NOT NULL AUTO_INCREMENT,
  first_name VARCHAR(45),
  last_name VARCHAR(45),
  occupation VARCHAR(45),
  clinic_id INT,
  PRIMARY KEY (staff_id)
  );

INSERT INTO staff VALUES (1, "Mordin", "Solus", "Surgeon", 1);
INSERT INTO staff VALUES (2, "John", "Shepard", "Physiotherapist", 1);
INSERT INTO staff VALUES (3, "Liara", "T'soni", "Psychologist", 1);
INSERT INTO staff VALUES (4, "Garrus", "Vakarian", "Nurse", 1);
INSERT INTO staff VALUES (5, "Doctor", "Alban", "Witch Doctor", 2);
INSERT INTO staff VALUES (6, "Karin", "Chakwas", "Dentist", 1);
INSERT INTO staff VALUES (7, "Luke", "Skywalker", "Nurse", 1);
INSERT INTO staff VALUES (8, "Han", "Solo", "Physiotherapist", 1);
INSERT INTO staff VALUES (9, "Leia", "Organa", "Psychologist", 1);
INSERT INTO staff VALUES (10, "Garrosh", "Hellscream", "Nurse", 2);


ALTER TABLE staff
ADD COLUMN boss_id INT;

UPDATE staff SET boss_id = 2 WHERE staff_id = 1;
UPDATE staff SET boss_id = 2 WHERE staff_id = 3;
UPDATE staff SET boss_id = 2 WHERE staff_id = 4;
UPDATE staff SET boss_id = 2 WHERE staff_id = 6;
UPDATE staff SET boss_id = 9 WHERE staff_id = 7;
UPDATE staff SET boss_id = 9 WHERE staff_id = 8;
UPDATE staff SET boss_id = 2 WHERE staff_id = 5;
 
CREATE TABLE treatments (
  treatment_id INT NOT NULL AUTO_INCREMENT,
  treatment_type VARCHAR(45),
  treatment_price INT,
  PRIMARY KEY (treatment_id)
  );
  
  INSERT INTO treatments VALUES (1, "Rest", 100);
  INSERT INTO treatments VALUES (2, "Surgery", 1000);
  INSERT INTO treatments VALUES (3, "Penicillin", 150);
  INSERT INTO treatments VALUES (4, "Antibiotics", 150);
  INSERT INTO treatments VALUES (5, "Cleanse evil spirits", 500);
  INSERT INTO treatments VALUES (6, "Exercise", 50);
  INSERT INTO treatments VALUES (7, "Therapy", 250);
  INSERT INTO treatments VALUES (8, "Remove tooth", 500);
  INSERT INTO treatments VALUES (9, "Herbal tea", 100);
  
  CREATE TABLE conditions (
  condition_id INT NOT NULL AUTO_INCREMENT,
  condition_type VARCHAR(45),
  contagious VARCHAR(45),
  PRIMARY KEY (condition_id)
  );
 
INSERT INTO conditions VALUES (1, "Flu", "Yes");
INSERT INTO conditions VALUES (2, "Broken leg", "No");
INSERT INTO conditions VALUES (3, "Brain tumor", "No");
INSERT INTO conditions VALUES (4, "Mysterious rash", "Maybe");
INSERT INTO conditions VALUES (5, "Tooth decay", "No");
INSERT INTO conditions VALUES (6, "Depression", "Sometimes");
INSERT INTO conditions VALUES (7, "Ingrown nail" , "No");
INSERT INTO conditions VALUES (8, "Tonsillitis", "Yes");
INSERT INTO conditions VALUES (9, "Pnemonia", "Yes");
INSERT INTO conditions VALUES (10, "Malaria", "Yes");
INSERT INTO conditions VALUES (11, "Mentall illness", "No");
INSERT INTO conditions VALUES (12, "Amnesia", "No");
INSERT INTO conditions VALUES (13, "Lazy", "No");


     
  CREATE TABLE symptoms (
  symptom_id INT NOT NULL AUTO_INCREMENT,
  symptom_type VARCHAR(45),
  PRIMARY KEY (symptom_id)
  );
  
  INSERT INTO symptoms VALUES (1, "Cough");
  INSERT INTO symptoms VALUES (2, "Sore throat");
  INSERT INTO symptoms VALUES (3, "Tooth ache");
  INSERT INTO symptoms VALUES (4, "Low mood");
  INSERT INTO symptoms VALUES (5, "Finger pain");
  INSERT INTO symptoms VALUES (6, "Leg pain");
  INSERT INTO symptoms VALUES (7, "Headache");
  INSERT INTO symptoms VALUES (8, "Muscle numbness");
  INSERT INTO symptoms VALUES (9, "Sweating");
  INSERT INTO symptoms VALUES (10, "Fever");
  INSERT INTO symptoms VALUES (11, "Chills");
  INSERT INTO symptoms VALUES (12, "Breathing difficulty");
  INSERT INTO symptoms VALUES (13, "Fatigue");
  INSERT INTO symptoms VALUES (14, "Memory loss");
  
  
  CREATE TABLE symptomsinpatient (
  symptom_id INT,
  patient_id INT,
  PRIMARY KEY (symptom_id, patient_id)
  );
  
  INSERT INTO symptomsinpatient VALUES (8,1);
  INSERT INTO symptomsinpatient VALUES (13,1);
  INSERT INTO symptomsinpatient VALUES (14,2);
  INSERT INTO symptomsinpatient VALUES (1,3);
  INSERT INTO symptomsinpatient VALUES (5,4);
  INSERT INTO symptomsinpatient VALUES (2,5);
  INSERT INTO symptomsinpatient VALUES (2,6);
  INSERT INTO symptomsinpatient VALUES (10,6);
  INSERT INTO symptomsinpatient VALUES (5,7);
  INSERT INTO symptomsinpatient VALUES (7,8);
  INSERT INTO symptomsinpatient VALUES (8,9);
  INSERT INTO symptomsinpatient VALUES (6,10);
  INSERT INTO symptomsinpatient VALUES (11,10);
  INSERT INTO symptomsinpatient VALUES (1,11);
  INSERT INTO symptomsinpatient VALUES (2,11);
  INSERT INTO symptomsinpatient VALUES (9,12);
  INSERT INTO symptomsinpatient VALUES (10,12);
  INSERT INTO symptomsinpatient VALUES (5,13);
  INSERT INTO symptomsinpatient VALUES (4,14);
  
  
  
   CREATE TABLE conditionsinpatient (
  condition_id INT,
  patient_id INT,
  PRIMARY KEY (condition_id, patient_id)
  );
  
  INSERT INTO conditionsinpatient VALUES (13,1);
  INSERT INTO conditionsinpatient VALUES (12,2);
  INSERT INTO conditionsinpatient VALUES (1,3);
  INSERT INTO conditionsinpatient VALUES (5,4);
  INSERT INTO conditionsinpatient VALUES (8,5);
  INSERT INTO conditionsinpatient VALUES (8,6);
  INSERT INTO conditionsinpatient VALUES (7,7);
  INSERT INTO conditionsinpatient VALUES (3,8);
  INSERT INTO conditionsinpatient VALUES (8,9);
  INSERT INTO conditionsinpatient VALUES (2,10);
  INSERT INTO conditionsinpatient VALUES (1,11);
  INSERT INTO conditionsinpatient VALUES (10,12);
  INSERT INTO conditionsinpatient VALUES (7,13);
  INSERT INTO conditionsinpatient VALUES (6,14);
  
  
  CREATE TABLE examination (
  examination_id INT NOT NULL AUTO_INCREMENT,
  patient_id INT,
  clinic_id INT,
  staff_id INT,
  condition_status VARCHAR(45),
  examination_date DATE,
  PRIMARY KEY (examination_id)
  );
  
INSERT INTO examination VALUES (1, 1, 1, 4, "Improved", "2021-10-08");
INSERT INTO examination VALUES (2, 2, 1, 3, "Improved", "2021-10-07");
INSERT INTO examination VALUES (3, 3, 1, 7, "Worse", "2021-10-12");
INSERT INTO examination VALUES (4, 4, 1, 6, "Worse", "2021-10-09");
INSERT INTO examination VALUES (5, 5, 1, 7, "Improved", "2021-09-30");
INSERT INTO examination VALUES (6, 6, 1, 4, "Worse", "2021-09-27");
INSERT INTO examination VALUES (7, 7, 1, 1, "Unchanged", "2021-10-05");
INSERT INTO examination VALUES (8, 8, 2, 5, "Much worse", "2021-10-01");
INSERT INTO examination VALUES (9, 9, 1, 4, "Improved", "2021-10-03");
INSERT INTO examination VALUES (10, 10, 1, 4, "Improved", "2021-10-07");
INSERT INTO examination VALUES (11, 11, 2, 10, "Improved", "2021-09-29");
INSERT INTO examination VALUES (12, 12, 1, 4, "Improved", "2021-09-28");
INSERT INTO examination VALUES (13, 13, 2, 5, "Oops", "2021-09-30");
INSERT INTO examination VALUES (14, 14, 1, 9, "Worse", "2021-10-04");
  

