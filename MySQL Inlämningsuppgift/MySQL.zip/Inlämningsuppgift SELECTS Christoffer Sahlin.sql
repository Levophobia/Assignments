USE Inlämningsuppgift;

SELECT p.first_name AS "Firstname", p.last_name AS "Lastname", date_of_birth AS "Date of Birth", current_status AS "Current Health Status", name AS "Clinic Name", condition_type AS "Condition", Contagious,
 treatment_type AS "Treatment", treatment_price AS "Treatment Cost", condition_status AS "Condition changes at last examination", examination_date AS "Last checkup", CONCAT(s.first_name, " ", s.last_name) AS "Examined by" ,
 Occupation FROM patients p
JOIN clinics c
ON p.clinic_id = c.clinic_id
JOIN conditionsinpatient cip
ON p.patient_id = cip.patient_id
JOIN conditions con
ON cip.condition_id = con.condition_id
JOIN treatments t
ON p.treatment_id = t.treatment_id
JOIN examination e
ON p.patient_id = e.patient_id 
JOIN staff s
ON e.staff_id = s.staff_id 
ORDER BY p.last_name;

/*
-- select satser
SELECT first_name, last_name, date_of_birth FROM patients
WHERE date_of_birth > "1990-01-01";


SELECT * FROM patients
WHERE patient_id BETWEEN 1 AND 4;


SELECT phone AS "patients phonenumbers starting with 158" FROM patients
WHERE phone LIKE "158%";

SELECT first_name, last_name, occupation FROM staff
ORDER BY last_name DESC;

-- join exempel many to many
SELECT first_name AS "first name", last_name AS "last name", symptom_type AS "symptom" FROM patients p
JOIN symptomsinpatient sip
ON p.patient_id = sip.patient_id
JOIN symptoms s
ON sip.symptom_id = s.symptom_id
ORDER BY p.last_name;


-- self join
SELECT s.first_name AS "staff firstname", s.last_name AS "staff lastname", b.first_name AS "boss firstname", b.last_name AS "boss lastname" FROM staff s
JOIN staff b
WHERE s.boss_id = b.staff_id;


-- VIEW for conditions in a patient
CREATE OR REPLACE VIEW patientsconditions AS
SELECT first_name AS "firstname", last_name AS "lastname", condition_type AS "conditions" FROM patients p 
INNER JOIN conditionsinpatient cip
ON p.patient_id = cip.patient_id
INNER JOIN conditions c
ON cip.condition_id = c.condition_id
ORDER BY last_name DESC;

SELECT * FROM patientsconditions
WHERE conditions = "flu";

-- subquery
SELECT * FROM patients
WHERE date_of_birth > (
SELECT AVG(date_of_birth) FROM patients 
WHERE current_status = "sick");

-- if statement
SELECT first_name, last_name, clinic_id, 
IF (clinic_id = 2, "small", "large") AS "chance of survival"
FROM patients;

-- Mattemagi
SELECT first_name, FLOOR(DATEDIFF(NOW(), date_of_birth) /365.25) AS age FROM patients;




